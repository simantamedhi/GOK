﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace PMR_MicroServiceApi_DeptCI.Common
{
    public class SQLDataHelper
    {
        public SqlConnection GetSqlConnection()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["DeptCIDBConnectionString"].ConnectionString;
            var connection = new SqlConnection(connectionString);
            connection.Open();
            return connection;
        }

        public int ExecuteNonQuery(string commandText, CommandType commandType, params SqlParameter[] commandParameters)
        {
            int affectedRows = 0;
            using (var connection = GetSqlConnection())
            {
                using (var command = new SqlCommand(commandText, connection))
                {
                    command.CommandType = commandType;
                    command.Parameters.AddRange(commandParameters);
                    affectedRows = command.ExecuteNonQuery();
                }
            }
            return affectedRows;
        }

        public DataTable ExecuteReader(string commandText)
        {
            var table = new DataTable();
            SqlDataReader reader = null;
            using (SqlConnection con = GetSqlConnection())
            {
                using (SqlCommand cmd = new SqlCommand(commandText, con))
                {
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        sda.Fill(table);
                    }
                }
            }
            return table;
        }

        public int ExecuteScalar(string commandText)
        {
            int count = 0;
            using (SqlConnection con = GetSqlConnection())
            {
                using (SqlCommand cmd = new SqlCommand(commandText, con))
                {
                    cmd.CommandType = CommandType.Text;
                    var result = cmd.ExecuteScalar();
                    if (result != null)
                        return count + 1;
                    else
                    {
                        return count;
                    }
                }
            }
        }
    }
}