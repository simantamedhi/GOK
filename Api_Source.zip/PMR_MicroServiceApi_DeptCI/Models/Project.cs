﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMR_MicroServiceApi_DeptCI.Models
{
    public class Project
    {
        public string ProjectType { get; set; }

        public string ProjectName { get; set; }

        public string Market { get; set; }

        public string Department { get; set; }

        public string PML { get; set; }

    }
}