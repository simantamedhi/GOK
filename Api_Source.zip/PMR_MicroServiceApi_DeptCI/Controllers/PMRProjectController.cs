﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Results;
using Newtonsoft.Json;
using PMR_MicroServiceApi_DeptCI.Common;
using PMR_MicroServiceApi_DeptCI.Models;

namespace PMR_MicroServiceApi_DeptCI.Controllers
{
    [Serializable]
    public class PMRProjectController : ApiController
    {
        public string DataTableToJSONWithJSONNet(DataTable table)
        {
            string JSONString = string.Empty;
            JSONString = JsonConvert.SerializeObject(table);
            return JSONString;
        }

        [HttpGet]
        public string GetAllMarket()
        {
            SQLDataHelper sQLDataHelper = new SQLDataHelper();

            var dataTable = sQLDataHelper.ExecuteReader("Select * from Market");
            var strMarket = DataTableToJSONWithJSONNet(dataTable);
            return strMarket;
        }

        [HttpGet]
        public string GetAllProjectType()
        {
            SQLDataHelper sQLDataHelper = new SQLDataHelper();
            var dataTable = sQLDataHelper.ExecuteReader("Select * from ProjectType");
            var strProjectType = DataTableToJSONWithJSONNet(dataTable);
            return strProjectType;
        }

        [HttpGet]
        public string GetAllProjects()
        {
            SQLDataHelper sQLDataHelper = new SQLDataHelper();

            var dataTable = sQLDataHelper.ExecuteReader("Select * from Project");
            var str = DataTableToJSONWithJSONNet(dataTable);
            return str;
        }

        [HttpPost]
        public void InsertProjectDetails(Project project)
        {

            SQLDataHelper sQLDataHelper = new SQLDataHelper();
            SqlParameter[] parameterList = {
                //  new SqlParameter("@Id",DBNull.Value),
                new SqlParameter("@ProjectName",project.ProjectName),
                new SqlParameter("@ProjectType",project.ProjectType),
                new SqlParameter("@Market",project.Market),
                new SqlParameter("@Department",project.Department),
                new SqlParameter("@PML",project.PML),
                new SqlParameter("@RegistrationDate", DateTime.Now.Date),
                new SqlParameter("@RegisterBy","A254039"),
                new SqlParameter("@Status","Active")
            };
            string query = string.Format("insert into Project(ProjectName,Market,Department,PML,RegistrationDate,RegisterBy,ProjectType,Status) values(@ProjectName,@Market,@Department,@PML,@RegistrationDate,@RegisterBy,@ProjectType,@Status)");
            var rowsUpdated = sQLDataHelper.ExecuteNonQuery(query, System.Data.CommandType.Text, parameterList);
        }
    }
}
