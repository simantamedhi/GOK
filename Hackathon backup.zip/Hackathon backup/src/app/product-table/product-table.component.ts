import { Component, OnInit, ViewChild, TemplateRef} from '@angular/core';
import {MatButtonModule, MatCheckboxModule, MatMenuModule, MatSelectionList, MatListOption,
  MatOptionModule,MatIconModule} from '@angular/material';
  import { NgbModal,NgbPopover,ModalDismissReasons,NgbCollapseModule } from '@ng-bootstrap/ng-bootstrap';
  import { MatDialog } from '@angular/material';
  import { ApiService } from '../services/apiService';
  import { Product,Notification } from '../model/GOkModel';
  import { Router } from '@angular/router';

@Component({
  selector: 'app-product-table',
  templateUrl: './product-table.component.html',
  styleUrls: ['./product-table.component.scss']
})
export class ProductTableComponent implements OnInit {
  enableGraph=false;
  product:any;
  notificationModel  = new Notification();
  notificationModeList = new Array<Notification>();
  @ViewChild('content')
  private content: TemplateRef<any>;
  @ViewChild('content1')
  private content1: TemplateRef<any>;
  typesOfShoes: string[] = ['Boots', 'Clogs', 'Loafers', 'Moccasins', 'Sneakers']
  Activity: any;
  selectedCustomerRadio: any;
  ProductId: any;
  NotificationType: {};
  constructor(private modalService: NgbModal,private _apiService: ApiService,private route: Router) { 
    this.getProductList();
    this.getActivityList();
    //this.getNotificationList();
  }

  ngOnInit() {
  }
  openConfigure(content,prodId:any){
    this.ProductId =prodId;
    this.modalService.open(this.content);
}
getProductList(){
  this._apiService.Get('GetAllTrucks').then(data => {
    if (data) {
      this.product=data;
      console.log(this.product);
    }
  }
  ).catch(data => {
    console.log("Get product failed")
    // alert("Please Enter Valid Credentials Or You are not authorized user")
  });
}
getActivityList(){
  this._apiService.Get('GetAllMaintainenceActivities').then(data => {
    if (data) {
      this.Activity=data;
      console.log(this.Activity);
    }
  }
  ).catch(data => {
    console.log("Get product failed")
    // alert("Please Enter Valid Credentials Or You are not authorized user")
  });
}
getNotificationList(){
  this._apiService.Get('GetNotificationType').then(data => {
    if (data) {
      this.NotificationType=data;
      console.log(this.Activity);
    }
  }
  ).catch(data => {
    console.log("Get product failed")
    // alert("Please Enter Valid Credentials Or You are not authorized user")
  });
}
openConfigure1(content1,prodId:any){
  this.ProductId =prodId;
  this.modalService.open(this.content1);
}
radiotoggle(id:any,conf:string){
  this.selectedCustomerRadio = id+conf;
  document.getElementById(this.selectedCustomerRadio)
}

saveConfig(prdId:any){
  for(let a=0;a<this.Activity.length;a++){
    // let selectedNoti1 = document.getElementById(this.Activity[a].ActivityId + 'a');
    // let selectedNoti2 = document.getElementById(this.Activity[a].ActivityId + 'b');
    // let selectedNoti3 = document.getElementById(this.Activity[a].ActivityId + 'c');
    this.notificationModel.ChassisId=prdId;
    this.notificationModel.NotificationTypeId=1;
    this.notificationModel.PendingActivityId=this.Activity[a].ActivityId;
    this.notificationModel.Status=0;
    this.notificationModel.UpdatedTime= new Date().toISOString().slice(0, 19).replace('T', ' ');
    this.notificationModel.UserId="A260617"
    this.notificationModeList.push(this.notificationModel);
  }
  
  this._apiService.Post('SaveNotificationAndCheckList',this.notificationModel).then(data => {
    if (data) {
      alert("Saved Successfully")
    }
  }
  ).catch(data => {
    alert("Saved Successfully")
    // alert("Please Enter Valid Credentials Or You are not authorized user")
  });
}

logout(){
  this.route.navigate(['/login']);
}
}
