import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';

@Component({
  selector: 'app-custom-graph',
  templateUrl: './custom-graph.component.html',
  styleUrls: ['./custom-graph.component.css']
})
export class CustomGraphComponent implements OnInit {
  options:Object;
  view: any[] = [700, 400];

  colorScheme = {
    domain: ['#5AA454', '#A10A28', '#C7B42C', '#AAAAAA']
  };
  constructor() { }

  ngOnInit() {
    Highcharts.chart('container1',{
      chart: {
          plotBackgroundColor: null,
          plotBorderWidth: 0,
          plotShadow: false
      },
      title: {
          text: 'GOK<br>Number of<br>Bus',
          align: 'center',
          verticalAlign: 'middle',
          y: 40
      },
      tooltip: {
          pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
      },
      plotOptions: {
          pie: {
              dataLabels: {
                  enabled: true,
                  distance: -50,
                  style: {
                      fontWeight: 'bold',
                      color: 'white'
                  }
              },
              startAngle: -90,
              endAngle: 90,
              center: ['50%', '75%']
          }
      },
      series: [{
          type: 'pie',
          name: 'Level',
          innerSize: '50%',
          data: [
              ['Battery check',   50],
              ['Corrosion check',       10],
              ['complete check',   350],
              ['Gear box',       90],
              {
                  name: 'Level 1',
                  y: 0.2,
                  dataLabels: {
                      enabled: false
                  }
              }
          ]
      }]
  });
  
  Highcharts.chart('container', {

    title: {
        text: 'Run Maintainence'
    },

    subtitle: {
        // text: 'FIDO CLUP'
    },

    yAxis: {
        title: {
            text: 'Number of bus'
        }
    },
    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle'
    },

    plotOptions: {
        series: {
            pointStart: 1
        }
    },

    series: [{
        name: 'Expected',
        data: [2, 2.5, 1.75, 5, 6, 3.75, 5]
    }, {
        name: 'Actual',
        data: [2.49, 2.40, 2.97, 2.98, 3.24, 3.02, 3.81, 4.04]
    }]

});
}

OpenDepDetail(){}
  }


